const md5 = require('md5');
const pino = require("pino");
const logger = pino({ level: process.env.LOG_LEVEL || 'info' });

const eduzzToken = '';

const isValidSid = (order) => {
    const expectedSid = md5(Object.keys(order).reduce((acc, curr) => acc + curr) + eduzzToken);
    return expectedSid == order.sid;
};

const products = [{
    id: '671302',
    classes: 10
}];

const registerOrder = (req, res) => {
    const order = req.body;
    logger.info(`New order received: ${JSON.stringify(order)}`);
    if (isValidSid(order)) {
        res.status(200).json({});
    } else {
        res.status(401).json({message: "Not authorized"});
    }

};

module.exports = {
    registerOrder
}