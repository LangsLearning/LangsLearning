const handler = require('./handler');

module.exports = {
    apply: app => {
        app.post('/orders', handler.registerOrder);
    }
};